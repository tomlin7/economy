import json
import random

from data import sync_data
from data import data
from data import users

import errors
import constants


def has_job(user: int):
    sync_data()
    return data['users'][user]['job'] != 0


# def user_exist(_id):
#     sync_data()
#     if :


def make_leaderboard():
    sync_data()
    # order function
    order = sorted(users.items(), key=lambda val: val[1]['score'], reverse=True)

    # ranks dict
    names = {
        'first': {'id': 0, 'name': "None", 'score': 0},
        'second': {'id': 0, 'name': "None", 'score': 0},
        'third': {'id': 0, 'name': "None", 'score': 0},
        'fourth': {'id': 0, 'name': "None", 'score': 0},
        'fifth': {'id': 0, 'name': "None", 'score': 0}
    }
    # assigning ranks
    for number, name in zip(range(5), names):
        # print(name)

        names[name]['id'] = str(order[number])[2:]

        x = 0
        while 1 == 1:
            if names[name]['id'][x] == "'":
                break
            x += 1
        names[name]['id'] = str(order[number])[2:x + 2]

        names[name]['name'] = users[names[name]['id']]['name']
        names[name]['score'] = users[names[name]['id']]['score']

        # print(names[name]['id'], names[name]['name'], names[name]['score'])
    return names


# Function to decide amount from job
# Switcher is dictionary data type here
def decide_score(job: int):
    sync_data()
    switcher = {
        1: random.randint(1700, 2000),
        2: random.randint(1400, 1700),
        3: random.randint(1100, 1400),
        4: random.randint(800, 1100),
        5: random.randint(600, 800),
        6: random.randint(400, 600)
    }

    # get() method of dictionary data type returns
    # value of passed argument if it is present
    # in dictionary otherwise second argument will
    # be assigned as default value of passed argument
    return switcher.get(job, "no job")


def find_job_with_name(job: str):
    sync_data()
    switcher = {
        "software engineer": 1,
        "product manager": 2,
        "data scientist": 3,
        "electrical engineer": 4,
        "network engineer": 5,
        "systems integrator": 6
    }

    # get() method of dictionary data type returns
    # value of passed argument if it is present
    # in dictionary otherwise second argument will
    # be assigned as default value of passed argument
    return switcher.get(job, 0)


def find_job_with_id(job: int):
    sync_data()
    switcher = {
        1: "Software Engineer",
        2: "Product Manager",
        3: "Data Scientist",
        4: "Electrical Engineer",
        5: "Network Engineer",
        6: "Systems Integrator"
    }

    # get() method of dictionary data type returns
    # value of passed argument if it is present
    # in dictionary otherwise second argument will
    # be assigned as default value of passed argument
    return switcher.get(job, "no job")


def save_data():
    sync_data()
    json.dump(data, open("money.json", "w"), indent=4)
    print("data saved.")


# noinspection SpellCheckingInspection
async def return_no_job(ctx):
    sync_data()
    await ctx.send(
        "You don't currently have a job to work at. You can use "
        "`?worklist` to see a list of the available jobs")


async def create_new_user_and_apply_for_job(ctx, userid, job_id):
    sync_data()
    _score = 0
    _new = {
        f'{userid}': {
            'name': ctx.author.name,
            'job': job_id,
            'score': _score
        }
    }
    data['users'].update(_new)
    await applied_for_job(ctx, job_id)


async def create_new_user(ctx, userid):
    sync_data()
    _score = 0
    _new = {
        f'{userid}': {
            'name': ctx.author.name,
            'job': 0,
            'score': _score
        }
    }
    data['users'].update(_new)
    await return_no_job(ctx)


async def applied_for_job(ctx, job_id):
    sync_data()
    if find_job_with_id(job_id) != "no job":
        msg1 = "<@{0}> Congratulations, you are now working as a **{1}**!" \
            .format(ctx.author.id, find_job_with_id(job_id))
        msg2 = "You start now, and your salary is **{0} coins per hour**." \
            .format(constants.salaries[job_id])
        await ctx.send(f"{msg1}\n{msg2}")
    else:
        await ctx.send("No job with that name.")


async def give_score(ctx, data_, userid, score: int):
    sync_data()
    data_['users'][userid]['score'] += score
    data_['users'][userid]['name'] = str(ctx.author)

    # following PEP 8: E501 (line length > 120 characters)
    pt1 = f"**Boss** Good stuff {ctx.author.name}, got the work done well."
    pt2 = f" You were given {score} coins for one hour of work."
    await ctx.send(f"{pt1}{pt2}")
    print("{0} was given {1} for his/her work.".format(ctx.author.name, score))
