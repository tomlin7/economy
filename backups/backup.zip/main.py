"""
the main economy-management file.
"""
import discord
from discord.ext import commands
from discord.ext.commands import Bot

import errors
import functions
import constants
from constants import Url
from constants import rank_emotes
from data import sync_data
from data import data

client: Bot = commands.Bot(command_prefix="?")
sync_data()


@client.event
async def on_ready():
    sync_data()
    print(f"We're in as {client.user.name} \nLatency {client.latency} \nfriends {client.user.relationships}")


@client.command(name="top", aliases=['leaderboard', 'rich'])
async def leaderboard(ctx):
    """
    shows the leaderboard based on amount of money.
    """
    sync_data()
    top = functions.make_leaderboard()
    message = []
    for emoji, rank in zip(rank_emotes, top):
        if top[rank]['name'] == "None":
            break
        pt1 = "\n{0} **{1}**".format(emoji, top[rank]['score'])
        pt2 = top[rank]['name']
        message.append(f"{pt1} - {pt2}")
    embed = discord.Embed(title=f"Richest Users in **{ctx.guild.name}**",
                          description="\n".join(message),
                          color=discord.Color.blue())
    await ctx.send(embed=embed)
    functions.save_data()


# noinspection SpellCheckingInspection
@client.command(name="work")
# @commands.cooldown(1, 120, BucketType.user)
async def work(ctx):
    """
    You can select a job from the list, and work on that job hourly for a payout!
    """
    sync_data()
    _id = str(ctx.author.id)
    try:
        test = data['users'][_id]
        if not functions.has_job(_id):
            await functions.return_no_job(ctx)
            return
        _score = functions.decide_score(data['users'][_id]['job'])
        await functions.give_score(ctx, data, _id, _score)

    except KeyError:
        await functions.create_new_user(ctx, _id)
    # saving data to json file
    functions.save_data()


# noinspection SpellCheckingInspection
@client.command(name="worklist")
async def work_list(ctx):
    """
    shows the list of available jobs and their respected salary
    """
    sync_data()
    embed = discord.Embed(title="Available Jobs",
                          description="You can select a job from the list, and work on that job hourly for a payout!",
                          color=discord.Color.blue())
    for job, salary in zip(constants.jobs, constants.salaries):
        embed.add_field(name=job, value="`{0}`".format(constants.salaries[salary]), inline=False)
    await ctx.send(embed=embed)
    functions.save_data()


@client.command(name="apply")
async def apply_for_job(ctx, *, job):
    """
    apply for a job, which is in work list
    """
    sync_data()
    job = str(job).lower()
    job_id = functions.find_job_with_name(job)
    _id = str(ctx.author.id)
    try:
        test = data['users'][_id]
        print("has job")
        data['users'][_id]['job'] = job_id
        await functions.applied_for_job(ctx, job_id)
    except KeyError:
        await functions.create_new_user_and_apply_for_job(ctx, ctx.author.id, job_id)
    functions.save_data()


# noinspection SpellCheckingInspection
@client.command(name="waldo", aliases=['whereswaldo'])
async def waldo(ctx):
    """
    find waldo.
    """
    await ctx.send(Url.waldo_url)


@work.error
async def work_error(ctx, error):
    if isinstance(error, commands.CommandOnCooldown):
        cool_down_message = "You need to wait **2 minutes** until you can work again!"
        await ctx.send(cool_down_message)


# noinspection SpellCheckingInspection
client.run('Nzc3MDIwODg2NDU1ODEyMTA2.X69XFw.xIFobbieghH4M7a0XvmB2JMBUQs')
